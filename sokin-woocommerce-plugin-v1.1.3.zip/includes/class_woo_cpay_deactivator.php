<?php

/**
 * Fired during plugin deactivation
 */
class WooCPay_Deactivator {
	
	public static function deactivate() {

	}

}
