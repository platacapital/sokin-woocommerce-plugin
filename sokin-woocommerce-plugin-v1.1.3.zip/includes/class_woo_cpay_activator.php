<?php

/**
 * Fired during plugin activation
 */
require_once('class_woo_cpay.php');

class WooCPay_Activator extends WooCPay {


	public static function activate() {
		// parent::create_tables();

	}

}
